
Passos para uso:

1. Execute o script `GerenciarWhatsApp.ps1` no PowerShell (botão direito > Executar com PowerShell)
2. Para transformar em EXE, use:
     Invoke-ps2exe -inputFile GerenciarWhatsApp.ps1 -outputFile GerenciarWhatsApp.exe -iconFile whatsapp_transfer.ico -requireAdmin
3. Para criar o atalho no Menu Iniciar, execute o `criar_atalho_menu_iniciar.ps1`
